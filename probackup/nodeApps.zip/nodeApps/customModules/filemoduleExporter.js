module.exports = {
    filereturned: function () {
        return "./home.html"
    }
}