var http = require('http');
var fs = require('fs');

//1. Create a server object with  listner
var server = http.createServer(function (request, response) {
    //parse the request and read the url
    if (request.url === "/home") {
        //2a. read for home page
        fs.readFile("./home.html", function (err, data) {
            if (err) {
                response.writeHead(401, { "Content-Type": "text.html" });
                response.write("resourse is not available");
                response.end();
            }
            response.writeHead(200, { "Content-Type": "text/html" });
            response.write(data);
            response.end();

        })
    } else {
        if (request.url === "/about") {
            if (err) {
                response.writeHead(401, { "Content-Type": "text.html" });
                response.write("resourse is not available");
                response.end();
            }
            response.writeHead(200, { "Content-Type": "text/html" });
            response.write(data);
            response.end();

        }

    }
});

server.listen(4060);
console.log("Server Started on port 4060");