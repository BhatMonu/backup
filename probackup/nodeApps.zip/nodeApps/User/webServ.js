//1. load express 
var express = require('express');
//1a. load the path module,this will be used by "static" middleware of express
//The path is standard node module
var path = require("path");

//return express instace to api 
var expressInstance = require("./dal");


//1c load the body parser
var bodyParser = require("body-parser");

//2.define an instance of express
var instance = express();

//3. configure all middleware,call use() method on express instance
//3a.for static files
instance.use(express.static(path.join(__dirname, "./../node_modules/jquery/dist/"))); //for configuring all the middleware

//3b.define express router for seggrigating
//urls for html page web request & rest api request
var router = express.Router();
//router must be the part of instance.

//3c.add the router objects in the express middleware
instance.use(router);

//3d. configure the body-parser middleware
//3d.1 use urlencoded as false to read data from http url as queryString/formmodel etc.
instance.use(bodyParser.urlencoded({
    extended: false
}));

//3d.2 use the json() parser for body-parser
instance.use(bodyParser.json());

expressInstance.getExpressInstance(instance);

//4. Create Web request handlers
//4a.This will return the home.html from views folder
router.get("/home", function (req, res) {
    res.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    },

    );
})

//6.start listening
instance.listen(4070, function () {
    console.log("started listeing on port 4070");

})