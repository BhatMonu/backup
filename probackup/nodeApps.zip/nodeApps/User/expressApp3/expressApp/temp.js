//1. load express 
var express = require('express');
//1a. load the path module,this will be used by "static" middleware of express
//The path is standard node module
var path = require("path");

//1b.import the data-module
var dataModel = require("./datamodel");

//1c load the body parser
var bodyParser = require("body-parser");

//1d. loading mongoose driver
var mongoose = require("mongoose");
//1e. set the global promise  to manage all sync calls 
//made by application using mongoose driver
mongoose.Promise = global.Promise;

//2.define an instance of express
var instance = express();

//3. configure all middleware,call use() method on express instance
//3a.for static files
instance.use(express.static(path.join(__dirname, "./../node_modules/jquery/dist/"))); //for configuring all the middleware

//3b.define express router for seggrigating
//urls for html page web request & rest api request
var router = express.Router();
//router must be the part of instance.

//3c.add the router objects in the express middleware
instance.use(router);

//3d. configure the body-parser middleware
//3d.1 use urlencoded as false to read data from http url as queryString/formmodel etc.
instance.use(bodyParser.urlencoded({
    extended: false
}));

//3d.2 use the json() parser for body-parser
instance.use(bodyParser.json());

//4. Create Web request handlers
//4a.This will return the home.html from views folder
router.get("/home", function (req, res) {
    res.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    },

    );
})

//5_1. Model-Schema-Mapping with collections on MongoDB And Establishing collectionswith it.
mongoose.connect("mongodb://localhost/ProductsAppDb", {
    useNewUrlParser: true
});

//5_1a.get the connection object
//if dbConnect is not undefined then the connection is successful.
var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log('Sorry Connection Not Established');
    return;
}

//5_1b. defined schema (recommend to have some attributes as per the collection)
// var productSchema = mongoose.Schema({
//     ProductId: Number,
//     ProductName: String,
//     CategoryName: String,
//     Manufacturer: String,
//     Price: Number
// });

var userSchema = mongoose.Schema({
    UserId: String,
    Password: String,
})

//5_1c. Map The schema with the collections
//                                  //name      //Schema        //collection
var userModel = mongoose.model("UserModel", userSchema, "UserModel");

//5_2.create rest api request handlers
instance.get("/api/users", function (req, res) {


    //5a. make call to DB for a collection mapped with model and expect all docuemnt from it
    userModel.find().exec(function (err, result) {
        //5b.if err occured the respond erro
        if (err) {
            res.statusCode = 500;
            res.send({
                status: res.statusCode,
                err: err
            });
        }
        res.send({
            status: 200,
            data: result
        });
    });

    // .if error occured hne 

});

instance.post("/api/createUser", function (req, res) {
    // var data = req.body; //read the req body
    // console.log(JSON.stringify(data));
    // var responseData = dataModel.addData(data);
    // res.send(JSON.stringify(responseData));
    // res.send("we recived data & Will look into it");


    // var prod = {
    //     ProductId: req.body.ProductId,
    //     ProductName: req.body.ProductName,
    //     CategoryName: req.body.CategoryName,
    //     Manufacturer: req.body.Manufacturer,
    //     Price: req.body.Price
    // }

    var userdata = {
        UserId: req.body.UserId,
        Password: req.body.Password,
    }

    var authValues = req.headers.authorization;
    console.log("authvalue" + authValues);

    //5b. Process values
    var credentials = authValues.split(" ")[1];
    var data = credentials.split(":");
    var userName = data[0];
    var password = data[1];
    //5c. may accesss usermodel from db?
    if (userName == "Anu" && password == "Anu") {
        // res.send(JSON.stringify(dataModel.getData()));
        userModel.create(userdata, function (err, result) {
            if (err) {
                res.statusCode = 500;
                res.send({
                    status: res.statusCode,
                    error: err
                });
            }
            console.log("result" + JSON.stringify(result));
            res.send({
                status: 200,
                data: result
            });
        });

    } else {
        res.statusCode = 401;
        res.send({
            status: res.statusCode,
            message: "UnAuthorized Access"
        })
    }

    console.log('body' + JSON.stringify(req.body));



});

instance.get("/api/products/:id", function (req, res) {
    //uses param property of request object to read
    //url parameter
    var id = req.params.id;
    console.log('Received id ' + id);
    var record = dataModel.getData().filter(function (v, idx) {
        return v.id == id;
    });
    res.send(JSON.stringify(record));
});



//Assignment on express 

instance.put("/api/products/:id", function (req, res) {
    //read the req id parameter
    //read the body
    //update array
    //respond array

    // var id = req.params.id;
    // var prevData = dataModel.getData();
    var body = req.body; //read the req body
    record = dataModel.updateData(body);
    res.send(JSON.stringify(record));
    // });
});

instance.delete("/api/products/:id", function (req, res) {
    //read the req id parameter
    //delete matched record array
    //respond array

    var id = req.params.id;
    record = dataModel.deleteData(id);
    res.send(JSON.stringify(record));

});

//6.start listening
instance.listen(4070, function () {
    console.log("started listeing on port 4070");

})


// db.Product.findAndModify({query:{ProductId:1011},update:{$set:{Price:200}}})
// db.orders.countDocuments( { ProductId: { $gt:  } }, { limit: 100 } )