// const userModel = require('./app');
// const productModel = require('./app');
var getValidData = require("./userModel");
//1b.import the data-module
var dataModel = require("./dataModel");
//5_2.create rest api request handlers

//1d. loading mongoose driver
var mongoose = require("mongoose");
//1e. set the global promise  to manage all sync calls 
//made by application using mongoose driver
mongoose.Promise = global.Promise;

//5_1. Model-Schema-Mapping with collections on MongoDB And Establishing collections with it.
mongoose.connect("mongodb://localhost/ProductsAppDb", {
    useNewUrlParser: true
});

//5_1a.get the connection object
//if dbConnect is not undefined then the connection is successful.
var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log('Sorry Connection Not Established');
    return;
}

var productSchema = mongoose.Schema({
    ProductId: Number,
    ProductName: String,
    CategoryName: String,
    Manufacturer: String,
    Price: Number
});

var userSchema = mongoose.Schema({
    UserId: String,
    Password: String,
})

//5_1c. Map The schema with the collections
//                                  //name      //Schema        //collection
var productModel = mongoose.model("Products", productSchema, "Products");
var userModel = mongoose.model("UserModel", userSchema, "UserModel");


module.exports = {
    getExpressInstance: (instance) => {
        // defined schema (recommend to have some attributes as per the collection)

        instance.get("/api/products", function (request, response) {
            //5a. read headeres for authorization values.
            //5a. make call to DB for a collection mapped with model and expect all docuemnt from it
            var data = getValidData.validateUser(request, response);
            //5c. may accesss usermodel from db?
            if (data) {
                dataModel.getData(productModel, function (err, result) {
                    if (err) {
                        response.send({
                            status: 500,
                            data: 'Error in fetching data.'
                        })
                    } else {
                        response.send({
                            status: 200,
                            data: result
                        })
                    }
                })

            } else {
                response.statusCode = 401;
                response.send({
                    status: response.statusCode,
                    message: "UnAuthorized Access"
                })
            }
        });


        instance.get("/api/users", function (req, res) {
            //5a. make call to DB for a collection mapped with model and expect all docuemnt from it
            userModel.find().exec(function (err, result) {
                //5b.if err occured the respond erro
                if (err) {
                    res.statusCode = 500;
                    res.send({
                        status: res.statusCode,
                        err: err
                    });
                }
                res.send({
                    status: 200,
                    data: result
                });
            });
        });

        instance.post("/api/products", function (req, res) {
            // var data = req.body; //read the req body
            // console.log(JSON.stringify(data));
            // var responseData = dataModel.addData(data);
            // res.send(JSON.stringify(responseData));
            // res.send("we recived data & Will look into it");


            var prod = {
                ProductId: req.body.ProductId,
                ProductName: req.body.ProductName,
                CategoryName: req.body.CategoryName,
                Manufacturer: req.body.Manufacturer,
                Price: req.body.Price
            }
            productModel.create(prod, function (err, result) {
                if (err) {
                    res.statusCode = 500;
                    res.send({
                        status: res.statusCode,
                        error: err
                    });
                }
                console.log("result" + JSON.stringify(result));
                res.send({
                    status: 200,
                    data: result
                });
            });

        });

        instance.post("/api/createUser", function (req, res) {
            var userdata = {
                UserId: req.body.UserId,
                Password: req.body.Password,
            }
            var data = getValidData.validateUser(req, res);
            //5c. may accesss usermodel from db?
            if (data) {
                // res.send(JSON.stringify(dataModel.getData()));
                console.log('data' + JSON.stringify(data))
                userModel.create(userdata, function (err, result) {
                    if (err) {
                        res.statusCode = 500;
                        res.send({
                            status: res.statusCode,
                            error: err
                        });
                    }
                    console.log("result" + JSON.stringify(result));
                    res.send({
                        status: 200,
                        data: result
                    });
                });

            } else {
                res.statusCode = 401;
                res.send({
                    status: res.statusCode,
                    message: "UnAuthorized Access"
                })
            }

            console.log('body' + JSON.stringify(req.body));



        });

        instance.get("/api/products/:id", function (req, res) {
            //uses param property of request object to read
            //url parameter
            var id = req.params.id;
            console.log('Received id ' + id);
            var record = dataModel.getData().filter(function (v, idx) {
                return v.id == id;
            });
            res.send(JSON.stringify(record));
        });



        //Assignment on express 

        instance.put("/api/products/:id", function (req, res) {
            //read the req id parameter
            //read the body
            //update array
            //respond array

            // var id = req.params.id;
            // var prevData = dataModel.getData();
            var body = req.body; //read the req body
            record = dataModel.updateData(body);
            res.send(JSON.stringify(record));
            // });
        });

        instance.delete("/api/products/:id", function (req, res) {
            //read the req id parameter
            //delete matched record array
            //respond array

            var id = req.params.id;
            record = dataModel.deleteData(id);
            res.send(JSON.stringify(record));

        });

    }
}





// db.Product.findAndModify({query:{ProductId:1011},update:{$set:{Price:200}}})
// db.orders.countDocuments( { ProductId: { $gt:  } }, { limit: 100 } )