var caller = require('./getexternaldata');

var options = {
    host: "apiapptrainingservice.azurewebsites.net",
    path: "/api/Products",
    method: "GET"
};

caller.getData(options)
    .then(function (receiveData) {
        console.log(JSON.stringify(receiveData))
    })
    .catch(function (error) {
        console.log(error)
    });