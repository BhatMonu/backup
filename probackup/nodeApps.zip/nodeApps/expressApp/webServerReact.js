var express = require("express");
// 1a. load the 'path' module. This will be used by "static" middleware
// of express. The 'path' is standard node module
var path = require("path");
var jwt = require("jsonwebtoken");
// 1b. import the data-module
var dataModel = require("./datamodel");
// 1c. load the body-parser
var bodyParser = require("body-parser");

// 1d. loading mongoose driver
var mongoose = require("mongoose");
// 1e. set the global promise to manage all async calls
// made by application using mongoose driver
mongoose.Promise = global.Promise;
// 1f. load cors package
var cors = require("cors");
// 2. define an instance of express
var instance = express();

// 3. configure all middlewares, call "use()" method on express instance
// 3a. static files
instance.use(
    express.static(path.join(__dirname, "./../node_modules/jquery/dist/"))
);

//3b. define express router for seggrigating urls for html page web requests and rest api requests.
var router = express.Router();
//3c. Add the router object in the express middleware.
instance.use(router);
//3d. configure the body-parser middleware
//3d.1 use urlencoded as false to read data from http url as querystring, formmodel etc.
instance.use(bodyParser.urlencoded({ extended: false }));
//3d.2 Use the json() parser for body parser
instance.use(bodyParser.json())
//4. create web request handlers.
//4a. This will return the home.html from views folder
/*instance.get("/home", function (req, resp) {
    resp.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    },
        function (error) {
            console.log("Resource not Found", + error.message);
        });
});*/
instance.use(cors());

router.get("/home", function (req, resp) {
    resp.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    });
});

/**********************************************************************************************/

// 5. Model-Schema-Mapping with collection on Mongo DB and establishing connection with it.
mongoose.connect("mongodb://localhost/PersonalInformation",
    { useNewUrlParser: true });
//5a. get the connection object
//if dbconnect is not undefined then the connection is successful.
var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log("Connection is not established");
    return;
}

//5b. define schema (recommended to have same attributes as per the collections)
var PersonalInfoSchema = mongoose.Schema({
    PersonalUniqueID: String,
    FullName: Object,
    Gender: String,
    DateOfBirth: String,
    Age: String,
    Address: Object,
    City: String,
    State: String,
    PinCode: String,
    PhoneNo: String,
    PhysicalDisability: String,
    MaritalStatus: String,
    EducationStatus: String,
    BirthSign: String
});

var userSchema = mongoose.Schema({
    UserID: String,
    UserName: String,
    Password: String,
    Role: String,
    RoleID: String,
    EmailAddress: String

});


var userTempSchema = mongoose.Schema({
    UserID: String,
    UserName: String,
    Password: String,
    Role: String,
    RoleID: String,
    EmailAddress: String

});

var tempSchema = mongoose.Schema({
    PersonalUniqueID: String,
    FullName: Object,
    Gender: String,
    DateOfBirth: String,
    Age: String,
    Address: Object,
    City: String,
    State: String,
    PinCode: String,
    PhoneNo: String,
    PhysicalDisability: String,
    MaritalStatus: String,
    EducationStatus: String,
    BirthSign: String
});

//5c. map the schema with the collection
//                                   name        Schema        collection
var personalInfoModel = mongoose.model("PersonalInfo", PersonalInfoSchema, "PersonalInfo")
var uModel = mongoose.model("Users", userSchema, "Users")
var tempModel = mongoose.model("tempCollection", tempSchema, "tempCollection")
var userTempModel = mongoose.model("userTempCollection", userTempSchema, "userTempCollection")
var jwtSettings = {
    jwtSecret: "dbcsbiobc0708hdfcyesbombob"
};



instance.set("jwtSecret", jwtSettings.jwtSecret);
var tokenStore = "";
// 7. authenticate user 
instance.post("/api/users/auth", function (request, response) {
    var user = {
        UserName: request.body.UserName,
        Password: request.body.Password,
    };

    console.log("In Auth User ", user);
    uModel.findOne({ UserName: request.body.UserName }, function (err, usr) {
        if (err) {
            //   console.log("Some error occured ");
            // throw error;
            response.send({
                statusCode: 202,
                message: "Sorry!Error occured"
            });
        }
        // 7a. if user not found the respond error 
        if (!usr) {
            // console.log("user not found");
            response.send({
                statusCode: 404,
                message: "Sorry!User is not available"
            });
        } else if (usr) {
            // 7b. user is available but password not match the 
            // respond error 
            console.log("In else if " + JSON.stringify(usr));
            if (usr.Password != user.Password) {
                // console.log("in password check");
                response.send({
                    statusCode: 404,
                    message: "Sorry!User Name and Password does not match"
                });
            } else {
                // 7c. sing-In the user and generate token 
                //  console.log("jwt token generate");
                var token = jwt.sign({ usr }, instance.get("jwtSecret"), {
                    expiresIn: 4500
                });
                console.log("in jwt", token);
                // save token globally 
                tokenStore = token;
                response.send({
                    statusCode: 200,
                    authenticated: true,
                    message: "Login Success",
                    token: token,
                    data: usr
                });
            }
        }
    });
});

/* #endregion */

// /* #region The code for Product API */
/* #region Create/Register User */
// 5. create a new user 
instance.post("/api/users/create", function (request, response) {

    var user = {
        UserID: request.body.UserID,
        UserName: request.body.UserName,
        Password: request.body.Password,
        EmailAddress: request.body.EmailAddress,
        Role: request.body.Role,
        RoleID: request.body.RoleID
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    // console.log("tokenReceived", tokenReceived)
    // 8b. verify the token 
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            uModel.create(user, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ statusCode: response.statusCode, message: err });
                }
                response.send({ statusCode: 200, message: res });
            });
        }
    });
});
/* #endregion */
/* #endregion */


instance.post("/api/users/createtemp", function (request, response) {

    var user = {
        UserID: request.body.UserID,
        UserName: request.body.UserName,
        Password: request.body.Password,
        EmailAddress: request.body.EmailAddress,
        Role: request.body.Role,
        RoleID: request.body.RoleID
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    // console.log("tokenReceived", tokenReceived)
    // 8b. verify the token 
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            userTempModel.create(user, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ statusCode: response.statusCode, message: err });
                }
                response.send({ statusCode: 200, message: res });
            });
        }
    });
});
/* #endregion */


//api to post/add product into db
instance.post("/api/addpersonalInfo", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var createdByUserRole = request.body.createdByRole;
    console.log("createdByUserRole", createdByUserRole);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        Gender: request.body.Gender,
        Age: request.body.Age,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        DateOfBirth: request.body.DateOfBirth,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PhoneNo: request.body.PhoneNo,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign,
        PhysicalDisability: request.body.PhysicalDisability,
        PinCode: request.body.PinCode
    };
    // pass the parsed object to "create()" method
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });


        }
    });
});


// //api to post/add product into db
instance.post("/api/temp/addpersonalInfo", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var createdByUserRole = request.body.createdByRole;
    console.log("createdByUserRole", createdByUserRole);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    // pass the parsed object to "create()" method
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            tempModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });


        }
    });
});


instance.get("/api/user/getPersonalInfo/:id", function (request, response) {
    // use "params" property of request object to read
    // url parameter
    var condition = {
        PersonalUniqueID: request.params.id
    }
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)

    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            personalInfoModel.find(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});


//api to get all users from db
instance.get("/api/users/allUsers", function (request, response) {

    // 8a. read request headers header contains bearer<space><token> 
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)
    // 8b. verify the token 
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            personalInfoModel.find().exec(function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});


instance.get("/api/users/allPendingUsers", function (request, response) {

    // 8a. read request headers header contains bearer<space><token> 
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)
    // 8b. verify the token 
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            tempModel.find().exec(function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});


//api to update product detail into db by Admin
instance.put("/api/updateuseradmin/:id", function (request, response) {
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var condition = {
        PersonalUniqueID: request.params.id
    }
    console.log("condition", JSON.stringify(condition));
    console.log("obj", JSON.stringify(obj));
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.updateOne(condition, obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({
                    status: 200,
                    data: res
                });
            });

        }
    });
});
//output -> {"status":200,"data":{"n":1,"nModified":1,"ok":1}}


//api to update product detail into db by operator and accessuser
instance.put("/api/updateuser/:id", function (request, response) {
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var condition = {
        PersonalUniqueID: request.params.id
    }
    console.log("condition", JSON.stringify(condition));
    console.log("obj", JSON.stringify(obj));
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            tempModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });

        }
    });
});


//api to delete data  from db
instance.delete("/api/deleteuser/:id", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.params.id
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({
                    status: 200,
                    data: res
                });
            });
        }
    });
});
// delete/reject temp data request with admin login
instance.delete("/api/deleteTempUser/:id", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.params.id
    }
    var condition1 = {
        UserID: request.params.id
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            tempModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                } else {
                    userTempModel.deleteOne(condition1, function (err, res) {
                        if (err) {
                            response.statusCode = 500;
                            response.send(err);
                        } else {
                            response.send({
                                status: 200,
                                data: res
                            });
                        }
                    });
                }
            });
        }
    });
});



// Approve operator's update or add request


instance.post("/api/users/approval/one", function (request, response) {
    //  alert(request.body.PersonalUniqueID);
    var obj = request.body;
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            tempModel.findOne({ PersonalUniqueID: request.body.PersonalUniqueID }, function (err, res) {
                if (err) {
                    response.send({
                        statusCode: 202,
                        message: "Sorry! Error occured"
                    });
                } else if (res) {
                    userTempModel.findOne({ UserID: request.body.PersonalUniqueID }, function (err1, res1) {
                        if (err1) {
                            response.send({
                                statusCode: 202,
                                message: "Sorry! Error occured"
                            });
                        }
                        response.send({
                            statusCode: 200
                        });
                    });
                }
            });
        }
    });
});


instance.put("/api/users/approval/two", function (request, response) {
    console.log(request.body.PersonalUniqueID);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            personalInfoModel.updateOne({ PersonalUniqueID: request.body.PersonalUniqueID }, obj, function (err2, res2) {
                if (err2) {
                    response.statusCode = 500;
                    response.send(err2);
                }
                else if (res2) {
                    response.send({
                        statusCode: 200,
                        data: res2
                    });
                }

            });
        }
    });
});



instance.delete("/api/users/approval/three", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.body.PersonalUniqueID
    }
    var condition1 = {
        UserID: request.body.PersonalUniqueID
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            tempModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.send({
                        statusCode: 202,
                        message: "Sorry! Error occured"
                    });
                } else if (res) {

                    userTempModel.deleteOne(condition1, function (err1, res1) {
                        if (err1) {
                            response.send({
                                statusCode: 202,
                                message: "Sorry! Error occured"
                            });
                        }
                        response.send({
                            statusCode: 200
                        });
                    });
                }
            });
        }
    });
});

//tempModel.deleteOne({ PersonalUniqueID: request.body.PersonalUniqueID }, function (err3, res3) {
//     if (err3) {
//         response.statusCode = 500;
//         response.send(err3);
//     } else {
//         response.send({
//             statusCode: 200,
//             data: res3
//         });
//     }
//});
//6. start listening
instance.listen(4070, function () {
    console.log("start listening on port 4070")
})
