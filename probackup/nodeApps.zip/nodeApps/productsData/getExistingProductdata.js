var productArray = [];

//2.
var extServerOptions = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/Products',
    method: 'GET'
};
//3.
function get() {
    http.request(extServerOptions, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (data) {
            productArray = JSON.parse(data);
            productArray.foreach(function (e) {
                console.log(JSON.stringify(e));
            });
        });

    }).end();
}