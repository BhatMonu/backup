console.log("NODE.JS")

var Employee ={
    EmpNo: 101,
    EmpName: "ABC"
};

console.log(JSON.stringify(Employee));
add();

function add(x,y){
    var res = parseFloat(x) + parseInt(y)
    console.log(res);
    
}

add(4, 5);